"""
Configuration files for AutoCSV Profiler Suite
"""
